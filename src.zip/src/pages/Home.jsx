import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>Bienvenido a la aplicación React con Vite y Ant Design</h1>
        </div>
    );
};

export default Home;
