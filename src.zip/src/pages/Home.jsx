import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>Bienvenido a Servicio Tecnco Maigas</h1>
        </div>
    );
};

export default Home;
