import React from 'react';
import { Form, Input, Button, Select, message } from 'antd';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const CrearUsuario = () => {
    const [form] = Form.useForm();
    const navigate = useNavigate();
    const apiUrl = `${import.meta.env.VITE_BACKEND_URL}/usuarios`;

    const manejarCrear = async (values) => {
        try {
            const token = localStorage.getItem('token');
            await axios.post(apiUrl, values, {
                headers: { Authorization: `Bearer ${token}` },
            });
            message.success('Usuario creado exitosamente');
            navigate('/usuarios');
        } catch (error) {
            message.error('Error al crear el usuario');
        }
    };

    return (
        <Form
            form={form}
            layout="vertical"
            onFinish={manejarCrear}
            style={{ maxWidth: '600px', margin: '0 auto' }}
        >
            <h1>Crear Usuario</h1>
            <Form.Item
                label="Nombre"
                name="nombre"
                rules={[{ required: true, message: 'Por favor ingrese el nombre' }]}
            >
                <Input />
            </Form.Item>
            <Form.Item
                label="Apellido"
                name="apellido"
                rules={[{ required: true, message: 'Por favor ingrese el apellido' }]}
            >
                <Input />
            </Form.Item>
            <Form.Item
                label="Correo Electrónico"
                name="correo_electronico"
                rules={[{ required: true, message: 'Por favor ingrese el correo electrónico' }]}
            >
                <Input />
            </Form.Item>
            <Form.Item
                label="Tipo de Usuario"
                name="tipo_usuario"
                rules={[{ required: true, message: 'Por favor seleccione un tipo de usuario' }]}
            >
                <Select>
                    <Select.Option value="admin">Admin</Select.Option>
                    <Select.Option value="usuario">Usuario</Select.Option>
                </Select>
            </Form.Item>
            <Button type="primary" htmlType="submit" block>
                Crear Usuario
            </Button>
        </Form>
    );
};

export default CrearUsuario;
