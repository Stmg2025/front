import React, { useState, useEffect } from 'react';
import { Table, Input, Button, Space, Card, message, Tag } from 'antd';
import { SearchOutlined, EnvironmentOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const { Search } = Input;

const ListaDirecciones = () => {
    const [direcciones, setDirecciones] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] = useState('');
    const navigate = useNavigate();

    const fetchDirecciones = async () => {
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(
                `${import.meta.env.VITE_BACKEND_URL}/direcciones`,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );

            // Obtener los datos de los clientes para cada dirección
            const direccionesConClientes = await Promise.all(
                response.data.map(async (direccion) => {
                    const clienteResponse = await axios.get(
                        `${import.meta.env.VITE_BACKEND_URL}/clientes/${direccion.cliente_codigo}`,
                        {
                            headers: { Authorization: `Bearer ${token}` }
                        }
                    );
                    return {
                        ...direccion,
                        cliente_nombre: clienteResponse.data.nombre
                    };
                })
            );

            setDirecciones(direccionesConClientes);
        } catch (error) {
            message.error('Error al cargar las direcciones');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchDirecciones();
    }, []);

    const handleSearch = (value) => {
        setSearchText(value.toLowerCase());
    };

    const filteredDirecciones = direcciones.filter(direccion =>
        direccion.direccion?.toLowerCase().includes(searchText) ||
        direccion.comuna?.toLowerCase().includes(searchText) ||
        direccion.ciudad?.toLowerCase().includes(searchText) ||
        direccion.cliente_nombre?.toLowerCase().includes(searchText)
    );

    const columns = [
        {
            title: 'Cliente',
            dataIndex: 'cliente_nombre',
            key: 'cliente_nombre',
            sorter: (a, b) => (a.cliente_nombre || '').localeCompare(b.cliente_nombre || ''),
        },
        {
            title: 'Dirección',
            key: 'direccion_completa',
            render: (_, record) => (
                <Space direction="vertical" size="small">
                    <span>
                        {record.direccion} {record.numero}
                        {record.depto_oficina && ` Depto/Of: ${record.depto_oficina}`}
                    </span>
                    <Space size="small">
                        {record.es_principal && (
                            <Tag color="green">Principal</Tag>
                        )}
                        <Tag color="blue">{record.tipo_direccion || 'No especificado'}</Tag>
                    </Space>
                </Space>
            ),
        },
        {
            title: 'Comuna',
            dataIndex: 'comuna',
            key: 'comuna',
            sorter: (a, b) => (a.comuna || '').localeCompare(b.comuna || ''),
        },
        {
            title: 'Ciudad',
            dataIndex: 'ciudad',
            key: 'ciudad',
            sorter: (a, b) => (a.ciudad || '').localeCompare(b.ciudad || ''),
        },
        {
            title: 'Región',
            dataIndex: 'region',
            key: 'region',
            sorter: (a, b) => (a.region || '').localeCompare(b.region || ''),
        },
        {
            title: 'Acciones',
            key: 'acciones',
            render: (_, record) => (
                <Button
                    type="primary"
                    icon={<EnvironmentOutlined />}
                    onClick={() => navigate(`/clientes/${record.cliente_codigo}/direcciones`)}
                >
                    Ver Todas
                </Button>
            ),
        },
    ];

    return (
        <div style={{ padding: '24px' }}>
            <Card title="Direcciones de Clientes">
                <Space direction="vertical" style={{ width: '100%' }} size="large">
                    <Search
                        placeholder="Buscar por cliente, dirección, comuna o ciudad"
                        onSearch={handleSearch}
                        onChange={(e) => handleSearch(e.target.value)}
                        style={{ maxWidth: 400 }}
                        allowClear
                    />
                    <Table
                        columns={columns}
                        dataSource={filteredDirecciones}
                        rowKey="id"
                        loading={loading}
                        pagination={{
                            pageSize: 10,
                            showSizeChanger: true,
                            showTotal: (total, range) =>
                                `${range[0]}-${range[1]} de ${total} direcciones`,
                        }}
                    />
                </Space>
            </Card>
        </div>
    );
};

export default ListaDirecciones;