import React, { useEffect, useState } from 'react';
import { Table, Button, Input, Modal, message, Space, AutoComplete } from 'antd';
import { EditOutlined, PlusOutlined, SearchOutlined, EnvironmentOutlined } from '@ant-design/icons';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import ClienteForm from './ClienteForm';

const Clientes = () => {
    const [clientes, setClientes] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchText, setSearchText] = useState('');
    const [searchedColumn, setSearchedColumn] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedCliente, setSelectedCliente] = useState(null);
    const navigate = useNavigate();

    const fetchClientes = async () => {
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`${import.meta.env.VITE_BACKEND_URL}/clientes`, {
                headers: { Authorization: `Bearer ${token}` },
            });
            setClientes(response.data);
        } catch (error) {
            message.error('Error al cargar clientes');
        } finally {
            setLoading(false);
        }
    };

    const getUniqueValues = (dataIndex) => {
        return Array.from(new Set(clientes.map(item => item[dataIndex]))).filter(Boolean);
    };

    const handleSearch = (selectedKeys, confirm, dataIndex) => {
        confirm();
        setSearchText(selectedKeys[0]);
        setSearchedColumn(dataIndex);
    };

    const handleReset = (clearFilters) => {
        clearFilters();
        setSearchText('');
    };

    const getColumnSearchProps = (dataIndex) => ({
        filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => (
            <div style={{ padding: 8 }}>
                <AutoComplete
                    options={getUniqueValues(dataIndex).map(value => ({ value: value?.toString() }))}
                    value={selectedKeys[0]}
                    onChange={value => setSelectedKeys(value ? [value] : [])}
                    onSelect={value => setSelectedKeys([value])}
                    style={{ width: 188, marginBottom: 8, display: 'block' }}
                >
                    <Input
                        placeholder={`Buscar ${dataIndex}`}
                        onPressEnter={() => handleSearch(selectedKeys, confirm, dataIndex)}
                    />
                </AutoComplete>
                <Space>
                    <Button
                        type="primary"
                        onClick={() => handleSearch(selectedKeys, confirm, dataIndex)}
                        icon={<SearchOutlined />}
                        size="small"
                        style={{ width: 90 }}
                    >
                        Buscar
                    </Button>
                    <Button
                        onClick={() => handleReset(clearFilters)}
                        size="small"
                        style={{ width: 90 }}
                    >
                        Limpiar
                    </Button>
                </Space>
            </div>
        ),
        filterIcon: filtered => <SearchOutlined style={{ color: filtered ? '#1890ff' : undefined }} />,
        onFilter: (value, record) =>
            record[dataIndex] ? record[dataIndex].toString().toLowerCase().includes(value.toLowerCase()) : '',
    });

    const handleCreate = () => {
        setSelectedCliente(null);
        setIsModalOpen(true);
    };

    const handleEdit = (record) => {
        setSelectedCliente(record);
        setIsModalOpen(true);
    };

    const handleDirecciones = (record) => {
        navigate(`/clientes/${record.codigo}/direcciones`);
    };

    const handleModalClose = () => {
        setIsModalOpen(false);
        fetchClientes();
    };

    useEffect(() => {
        fetchClientes();
    }, []);

    const columns = [
        {
            title: 'RUT',
            dataIndex: 'rut',
            key: 'rut',
            ...getColumnSearchProps('rut'),
            sorter: (a, b) => a.rut.localeCompare(b.rut),
        },
        {
            title: 'Nombre',
            dataIndex: 'nombre',
            key: 'nombre',
            ...getColumnSearchProps('nombre'),
            sorter: (a, b) => a.nombre.localeCompare(b.nombre),
        },
        {
            title: 'Teléfono',
            dataIndex: 'fono',
            key: 'fono',
            ...getColumnSearchProps('fono'),
        },
        {
            title: 'Acciones',
            key: 'acciones',
            render: (_, record) => (
                <Space>
                    <Button
                        type="text"
                        icon={<EditOutlined style={{ fontSize: '16px', color: '#666' }} />}
                        onClick={() => handleEdit(record)}
                    />
                    <Button
                        type="text"
                        icon={<EnvironmentOutlined style={{ fontSize: '16px', color: '#1890ff' }} />}
                        onClick={() => handleDirecciones(record)}
                    />
                </Space>
            ),
        },
    ];

    return (
        <div style={{ padding: '24px' }}>
            <h1>Clientes</h1>
            <Button
                type="primary"
                onClick={handleCreate}
                style={{
                    marginBottom: 20,
                    backgroundColor: '#ff4d4f',
                    borderColor: '#ff4d4f'
                }}
                icon={<PlusOutlined />}
            >
                Crear Cliente
            </Button>
            <Table
                dataSource={clientes}
                columns={columns}
                rowKey="codigo"
                loading={loading}
                pagination={{
                    pageSize: 10,
                    showSizeChanger: true,
                    showTotal: (total, range) => `${range[0]}-${range[1]} de ${total} clientes`,
                }}
            />
            <Modal
                title={selectedCliente ? 'Editar Cliente' : 'Crear Cliente'}
                open={isModalOpen}
                footer={null}
                onCancel={() => setIsModalOpen(false)}
            >
                <ClienteForm
                    cliente={selectedCliente}
                    onClose={handleModalClose}
                />
            </Modal>
        </div>
    );
};

export default Clientes;