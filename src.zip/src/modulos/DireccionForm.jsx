import React, { useState, useEffect } from 'react';
import { Form, Input, Select, Button, Switch, Space, Row, Col, message } from 'antd';
import axios from 'axios';

const { Option } = Select;

const DireccionForm = ({ direccion, clienteCodigo, onClose, esPrimeraDireccion }) => {
    const [form] = Form.useForm();
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if (direccion) {
            form.setFieldsValue(direccion);
        } else {
            form.resetFields();
            // Si es la primera dirección, establecer es_principal como true
            if (esPrimeraDireccion) {
                form.setFieldsValue({ es_principal: true });
            }
        }
    }, [direccion, form, esPrimeraDireccion]);

    const handleSubmit = async (values) => {
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            if (direccion) {
                await axios.put(
                    `${import.meta.env.VITE_BACKEND_URL}/direcciones/${direccion.id}`,
                    values,
                    {
                        headers: { Authorization: `Bearer ${token}` }
                    }
                );
                message.success('Dirección actualizada exitosamente');
            } else {
                await axios.post(
                    `${import.meta.env.VITE_BACKEND_URL}/direcciones`,
                    {
                        ...values,
                        cliente_codigo: clienteCodigo
                    },
                    {
                        headers: { Authorization: `Bearer ${token}` }
                    }
                );
                message.success('Dirección creada exitosamente');
            }
            onClose();
        } catch (error) {
            message.error('Error al guardar la dirección');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Form
            form={form}
            layout="vertical"
            onFinish={handleSubmit}
            initialValues={{
                pais: 'Chile',
                tipo_direccion: 'Casa',
                es_principal: esPrimeraDireccion
            }}
        >
            <Row gutter={16}>
                <Col span={16}>
                    <Form.Item
                        name="direccion"
                        label="Dirección"
                        rules={[{ required: true, message: 'Por favor ingrese la dirección' }]}
                    >
                        <Input placeholder="Ingrese la calle" />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        name="numero"
                        label="Número"
                        rules={[{ required: true, message: 'Por favor ingrese el número' }]}
                    >
                        <Input placeholder="Número" />
                    </Form.Item>
                </Col>
            </Row>

            <Row gutter={16}>
                <Col span={12}>
                    <Form.Item
                        name="depto_oficina"
                        label="Departamento/Oficina"
                    >
                        <Input placeholder="Departamento, Oficina, Local, etc." />
                    </Form.Item>
                </Col>
                <Col span={12}>
                    <Form.Item
                        name="tipo_direccion"
                        label="Tipo de Dirección"
                        rules={[{ required: true, message: 'Por favor seleccione el tipo' }]}
                    >
                        <Select>
                            <Option value="Casa">Casa</Option>
                            <Option value="Trabajo">Trabajo</Option>
                            <Option value="Oficina">Oficina</Option>
                            <Option value="Otro">Otro</Option>
                        </Select>
                    </Form.Item>
                </Col>
            </Row>

            <Row gutter={16}>
                <Col span={8}>
                    <Form.Item
                        name="comuna"
                        label="Comuna"
                        rules={[{ required: true, message: 'Por favor ingrese la comuna' }]}
                    >
                        <Input placeholder="Comuna" />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        name="ciudad"
                        label="Ciudad"
                        rules={[{ required: true, message: 'Por favor ingrese la ciudad' }]}
                    >
                        <Input placeholder="Ciudad" />
                    </Form.Item>
                </Col>
                <Col span={8}>
                    <Form.Item
                        name="region"
                        label="Región"
                        rules={[{ required: true, message: 'Por favor ingrese la región' }]}
                    >
                        <Input placeholder="Región" />
                    </Form.Item>
                </Col>
            </Row>

            <Row gutter={16}>
                <Col span={12}>
                    <Form.Item
                        name="codigo_postal"
                        label="Código Postal"
                    >
                        <Input placeholder="Código Postal" />
                    </Form.Item>
                </Col>
                <Col span={12}>
                    <Form.Item
                        name="pais"
                        label="País"
                    >
                        <Input disabled />
                    </Form.Item>
                </Col>
            </Row>

            <Form.Item
                name="referencia"
                label="Referencia"
            >
                <Input.TextArea
                    placeholder="Indicaciones adicionales para encontrar la dirección"
                    rows={3}
                />
            </Form.Item>

            <Form.Item
                name="es_principal"
                valuePropName="checked"
            >
                <Switch
                    checkedChildren="Dirección Principal"
                    unCheckedChildren="Dirección Secundaria"
                    disabled={esPrimeraDireccion}
                />
            </Form.Item>

            <Form.Item>
                <Space>
                    <Button type="primary" htmlType="submit" loading={loading}>
                        {direccion ? 'Actualizar' : 'Crear'}
                    </Button>
                    <Button onClick={onClose}>
                        Cancelar
                    </Button>
                </Space>
            </Form.Item>
        </Form>
    );
};

export default DireccionForm;