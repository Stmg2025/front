import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Modal, message, Space, Tag } from 'antd';
import { EditOutlined, DeleteOutlined, PlusOutlined, HomeOutlined, BankOutlined } from '@ant-design/icons';
import axios from 'axios';
import DireccionForm from './DireccionForm';

const Direcciones = ({ clienteCodigo, clienteNombre }) => {
    const [direcciones, setDirecciones] = useState([]);
    const [loading, setLoading] = useState(false);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [selectedDireccion, setSelectedDireccion] = useState(null);

    const fetchDirecciones = async () => {
        setLoading(true);
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(
                `${import.meta.env.VITE_BACKEND_URL}/direcciones/cliente/${clienteCodigo}`,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            setDirecciones(response.data);
        } catch (error) {
            message.error('Error al cargar las direcciones');
            console.error('Error:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (clienteCodigo) {
            fetchDirecciones();
        }
    }, [clienteCodigo]);

    const handleCreate = () => {
        setSelectedDireccion(null);
        setIsModalVisible(true);
    };

    const handleEdit = (record) => {
        setSelectedDireccion(record);
        setIsModalVisible(true);
    };

    const handleDelete = async (id) => {
        try {
            const token = localStorage.getItem('token');
            await axios.delete(
                `${import.meta.env.VITE_BACKEND_URL}/direcciones/${id}`,
                {
                    headers: { Authorization: `Bearer ${token}` }
                }
            );
            message.success('Dirección eliminada exitosamente');
            fetchDirecciones();
        } catch (error) {
            if (error.response?.data?.error === 'No se puede eliminar la única dirección activa del cliente') {
                message.error('No se puede eliminar la única dirección del cliente');
            } else {
                message.error('Error al eliminar la dirección');
            }
        }
    };

    const handleModalClose = () => {
        setIsModalVisible(false);
        fetchDirecciones();
    };

    const getTipoDireccionIcon = (tipo) => {
        switch (tipo) {
            case 'Casa':
                return <HomeOutlined />;
            case 'Oficina':
            case 'Trabajo':
                return <BankOutlined />;
            default:
                return null;
        }
    };

    const columns = [
        {
            title: 'Tipo',
            dataIndex: 'tipo_direccion',
            key: 'tipo_direccion',
            render: (tipo) => (
                <Space>
                    {getTipoDireccionIcon(tipo)}
                    {tipo}
                </Space>
            ),
        },
        {
            title: 'Dirección',
            dataIndex: 'direccion',
            key: 'direccion',
            render: (text, record) => (
                <>
                    {text} {record.numero}
                    {record.depto_oficina && ` Depto/Of: ${record.depto_oficina}`}
                    {record.es_principal && (
                        <Tag color="green" style={{ marginLeft: 8 }}>
                            Principal
                        </Tag>
                    )}
                </>
            ),
        },
        {
            title: 'Comuna',
            dataIndex: 'comuna',
            key: 'comuna',
        },
        {
            title: 'Ciudad',
            dataIndex: 'ciudad',
            key: 'ciudad',
        },
        {
            title: 'Referencia',
            dataIndex: 'referencia',
            key: 'referencia',
            ellipsis: true,
        },
        {
            title: 'Acciones',
            key: 'acciones',
            render: (_, record) => (
                <Space>
                    <Button
                        type="text"
                        icon={<EditOutlined style={{ fontSize: '16px', color: '#1890ff' }} />}
                        onClick={() => handleEdit(record)}
                    />
                    <Button
                        type="text"
                        icon={<DeleteOutlined style={{ fontSize: '16px', color: '#ff4d4f' }} />}
                        onClick={() => handleDelete(record.id)}
                        disabled={record.es_principal && direcciones.length === 1}
                    />
                </Space>
            ),
        },
    ];

    return (
        <Card
            title={`Direcciones de ${clienteNombre}`}
            extra={
                <Button
                    type="primary"
                    onClick={handleCreate}
                    icon={<PlusOutlined />}
                >
                    Agregar Dirección
                </Button>
            }
        >
            <Table
                dataSource={direcciones}
                columns={columns}
                rowKey="id"
                loading={loading}
                pagination={false}
            />
            <Modal
                title={selectedDireccion ? 'Editar Dirección' : 'Nueva Dirección'}
                open={isModalVisible}
                onCancel={() => setIsModalVisible(false)}
                footer={null}
                width={800}
            >
                <DireccionForm
                    direccion={selectedDireccion}
                    clienteCodigo={clienteCodigo}
                    onClose={handleModalClose}
                    esPrimeraDireccion={direcciones.length === 0}
                />
            </Modal>
        </Card>
    );
};

export default Direcciones;